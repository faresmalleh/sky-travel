#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <time.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "avis.h"

void
on_afficher_avis_c_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *avis_a	;
GtkWidget *treeview3 ;
avis_a = lookup_widget(objet_graphique,"avis_a");
treeview3 = lookup_widget(objet_graphique,"treeview3");
afficher_avis (treeview3);
}


void
on_ajouter_avis__clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{

  time_t T= time(NULL);
  struct  tm tm = *localtime(&T);

FILE *f;


avis k ;

f=fopen("avis.txt","a+");
GtkWidget *avis_c;

GtkWidget *cin;
GtkWidget *texte;
GtkWidget *id_c;

avis_c = lookup_widget(objet_graphique,"avis_c");

texte=lookup_widget(objet_graphique,"entry221");
cin=lookup_widget(objet_graphique,"entry220");
id_c=lookup_widget(objet_graphique,"entry223");

strcpy(k.texte,gtk_entry_get_text(GTK_ENTRY(texte)));
strcpy(k.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(k.id_c,gtk_entry_get_text(GTK_ENTRY(id_c)));


    sprintf(k.date,"%02d/%02d/%04d",tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);




fprintf(f,"%s %s %s %s\n",k.date,k.texte,k.id_c,k.cin);
fclose(f);




}


void
on_supprimer_avis_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *cin;
	char cin1[100];
GtkWidget *avis_c;
avis_c = lookup_widget(objet_graphique,"avis_c");
        cin=lookup_widget(objet_graphique,"entry222");
	strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));

	supprimer_avis(cin1);
	gtk_entry_set_text(GTK_ENTRY(cin), "");
}


void
on_afficher_avis_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *avis_c;

avis_c = lookup_widget(objet_graphique,"avis_c");
GtkWidget *treeview2;
treeview2 = lookup_widget(objet_graphique,"treeview2");
afficher_avis (treeview2);
}


void
on_modoifier_avis_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
char cin1[100], texte1[300],id_c1[100];
GtkWidget *texte;
GtkWidget *cin;
GtkWidget *id_c;
avis k;
GtkWidget *avis_c;
GtkWidget *treeview2 ;
avis_c = lookup_widget(objet_graphique,"avis_c");

texte=lookup_widget(objet_graphique,"entry221");
cin=lookup_widget(objet_graphique,"entry222");
id_c=lookup_widget(objet_graphique,"entry223");
strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin))); 
strcpy(texte1,gtk_entry_get_text(GTK_ENTRY(texte)));
strcpy(id_c1,gtk_entry_get_text(GTK_ENTRY(id_c)));
treeview2 = lookup_widget(objet_graphique,"treeview2");
modifier_avis(cin1,texte1,id_c1);

}

