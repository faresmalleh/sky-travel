#ifndef FONC_H_INCLUDED
#define FONC_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

//structure Avis 
typedef struct
{ 
char date[200];
char texte[2000];
char id_c [100];
char cin [10];
}avis ;
void afficher_avis (GtkTreeView *treeview2);
void supprimer_avis (char cin1 []);
void modifier_avis(char ida1 [],char texte_c[]);

#endif

