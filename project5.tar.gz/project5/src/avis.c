#include<stdlib.h>
#include<stdio.h>
#include <string.h>
#include "avis.h"
#include <gtk/gtk.h>
#include <time.h>
//afficher avis client
void afficher_avis (GtkTreeView *treeview2)
{

enum
{

 DATE,
 TEXTE,
 ID_C,
 CIN,
 COL3
};


GtkCellRenderer *renderer;
GtkTreeViewColumn * column;
GtkTreeIter iter;
GtkListStore *store;
avis k;


FILE *f;

store=NULL;
store=gtk_tree_view_get_model(treeview2);
if (store == NULL)
{
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("DATE",renderer,"text",DATE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("TEXTE",renderer,"text",TEXTE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("ID_C",renderer,"text",ID_C,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2),column);
		
                renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("CIN",renderer,"text",CIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2),column);
		
		
 	

	
}
	store=gtk_list_store_new(COL3,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("avis.txt","r");
if (f == NULL ) {return;}
else
{
while (fscanf(f,"%s %s %s %s",k.date,k.texte,k.id_c,k.cin)!=EOF) {

	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,DATE,k.date,TEXTE,k.texte,ID_C,k.id_c,CIN,k.cin,-1);
}
fclose(f);
}
	gtk_tree_view_set_model(GTK_TREE_VIEW(treeview2),GTK_TREE_MODEL(store));
	g_object_unref(store);
}
//supprimer un avis 
void supprimer_avis (char cin1[100]) 
{
 
  FILE *f;
  FILE *f_tmp;
  
char id_c[300];
char cin[300];
char date[300];
char texte[300];
 

  f=fopen("avis.txt","a+");
	f_tmp=fopen("avis_tmp.txt","a+");
  while(fscanf(f,"%s %s %s %s\n",date,texte,id_c,cin)!=EOF)
        {
          if (strcmp(cin,cin1)!=0)
          {
            fprintf(f_tmp,"%s %s %s %s\n",date,texte,id_c,cin);
          }
  //else
                  //{
                   // fprintf(f,"%s %s %s %s %s \n",nom,prenom,cin,date,message);
                  //}
          
        }
        fclose(f);
      	fclose(f_tmp);

      	remove("avis.txt");
      	rename("avis_tmp.txt","avis.txt");
}
void modifier_avis(char cin1 [300],char texte_c [300])
{
FILE *f;
FILE* f_tmp;


char id_c[300];
char cin[300];
char date[300];
char texte[300];
 

f=fopen("avis.txt","r");
  f_tmp=fopen("avis_tmp.txt","a+");
  if (f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s",date,texte,id_c,cin)!=EOF)
          {
                if (strcmp(cin,cin1)!=0)
                  {
                   fprintf(f_tmp,"%s %s %s %s\n",date,texte,id_c,cin);
                   
                   }
               else
                 {
                   fprintf(f_tmp,"%s %s %s %s\n",date,texte_c,id_c,cin);
                 }
          }
     }
          fclose(f);
          fclose(f_tmp);


     
          rename("avis_tmp.txt","avis.txt");

  
}
