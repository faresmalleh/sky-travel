#include <gtk/gtk.h>


void
on_afficher_avis_c_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouter_avis__clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_modufier_avis_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_avis_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_afficher_avis_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modoifier_avis_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
